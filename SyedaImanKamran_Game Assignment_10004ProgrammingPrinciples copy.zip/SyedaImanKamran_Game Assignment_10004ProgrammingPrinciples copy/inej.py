#inej attributes

inejclever = 0
inejagility = 2
inejcamo = 2


#challenge 1
def ic1():
    print("\nInej knows her way around the city and can crawl into anything that will allow her body through it. \nShe can sneak her way over the wired fences by gracefully jumping from building to building without a sound.")
   
#challenge 2
def ic2():
    print("\nInej has the map and goes to Ravka to destroy it, fighting anyone on her way.")

#challenge 3
def ic3():
    print("\nInej has to fight pekka.")