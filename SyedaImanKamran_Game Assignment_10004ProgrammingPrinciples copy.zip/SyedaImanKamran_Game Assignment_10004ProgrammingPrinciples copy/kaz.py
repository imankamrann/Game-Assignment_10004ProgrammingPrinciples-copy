#kaz attributes

kazclever = 2
kazagility = -1
kazcamo = 0


#challenge 1
def kc1():
    print("\nKaz always has a plan, and one of them includes how to break into Pekkas high security building. \nHe knows how to unlock any door, disguise as any worker and sneak through into any location. ")
    
#challenge 2
def kc2():
    print("\nKaz has the map and goes to Ravka to destroy it, fighting anyone on his way.")

#challenge 3
def kc3():
    print("\nKaz has to fight pekka")
